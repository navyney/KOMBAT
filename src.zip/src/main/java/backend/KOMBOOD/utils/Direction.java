package backend.KOMBOOD.utils;

public enum Direction {
    UP, UPRIGHT, DOWNRIGHT, DOWN, DOWNLEFT, UPLEFT
}
