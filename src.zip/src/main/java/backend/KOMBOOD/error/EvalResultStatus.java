package backend.KOMBOOD.error;

public enum EvalResultStatus {
    MOVE,DONE,SHOOT,EXECUTE
    //,NOT_EXECUTE
}
