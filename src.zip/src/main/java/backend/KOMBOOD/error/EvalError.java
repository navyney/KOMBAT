package backend.KOMBOOD.error;

public class EvalError extends Throwable {
    public EvalError(String s) {
    }
}
