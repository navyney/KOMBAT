public interface iStrategy {
     EvalResultStatus evaluator(Minion minion) throws EvalError;
}
