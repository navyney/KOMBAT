public enum Direction {
    UP, UPRIGHT, DOWNRIGHT, DOWN, DOWNLEFT, UPLEFT
}
