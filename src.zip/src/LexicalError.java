public class LexicalError extends Exception {
    public LexicalError(String s) {
    }
}
